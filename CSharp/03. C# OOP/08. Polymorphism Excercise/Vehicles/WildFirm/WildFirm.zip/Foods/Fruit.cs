﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WildFirm.Foods
{
    public class Fruit : BaseFood
    {
        public Fruit(int quantity) : base(quantity)
        {
        }
    }
}
